Example Description

This example describes how to use USI UART TX to simulate clock source

Required Components:
    Oscilloscope

USI UART pin mappings used in this test demo:
            PB20(TX)
            PB21(RX)

Connect the TX pin of USI UART with the oscilloscope, and 
we can watch the clock source waveform we want to generate.

This example shows: 
1. Clock signal output from USI UART_TX to oscilloscope
